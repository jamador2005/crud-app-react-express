import { apiRequest as baseApiRequest } from "@/lib/queryClient";

// Re-export the base apiRequest function
export const apiRequest = baseApiRequest;

// Additional API utility functions can be added here as needed
